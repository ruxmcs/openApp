# encoding: utf8
from __future__ import unicode_literals


# stop words as whitespace-separated list
STOP_WORDS = set("""
。
、
""".split())

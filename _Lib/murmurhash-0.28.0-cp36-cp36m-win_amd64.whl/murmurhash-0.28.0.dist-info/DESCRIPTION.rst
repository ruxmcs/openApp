Cython bindings for MurmurHash2
*******************************

.. image:: https://travis-ci.org/explosion/murmurhash.svg?branch=master
    :target: https://travis-ci.org/explosion/murmurhash
    :alt: Build Status

.. image:: https://img.shields.io/pypi/v/murmurhash.svg   
    :target: https://pypi.python.org/pypi/murmurhash
    :alt: pypi Version



# -*- coding: UTF-8 -*-
import sys
import time
import os
from os.path import abspath, basename, dirname, join, normpath
from ctypes import *
import platform

class NBNER:

    __SEG_INSTANCE = None # singleton
    __BASE_PATH = dirname(abspath(__file__))

    __DATA_PATH = __BASE_PATH +"/"+"data/"

    platform_info = platform.architecture()
    if platform_info[0]=='64bit':
        __DLL_PATH= normpath(join(__BASE_PATH,'lib/libnb_ner.so'))
    else:
        print 'error platform'
        sys.exit(-1)

    def __init__(self,dll_path):

        self.dll = cdll.LoadLibrary(dll_path)

        self.init_ner = getattr(self.dll, 'init_ner')
        self.get_entity = getattr(self.dll, 'get_entity')

        NBNER.__fill_prototype(self.init_ner, c_bool, [c_char_p])
        NBNER.__fill_prototype(self.get_entity, c_char_p, [c_char_p])

    def seg_sentence(self,sentence):

        result = self.get_entity(sentence)
        return result

    @staticmethod
    def get_instance(model_name, data_path=__DATA_PATH,dll_path=__DLL_PATH):

        if not NBNER.__SEG_INSTANCE:
            NBNER.__SEG_INSTANCE = NBNER(dll_path) 

        if not NBNER.__SEG_INSTANCE.init_ner(data_path+model_name):
            NBNER.__SEG_INSTANCE=None
            return None
            
        return NBNER.__SEG_INSTANCE

    @staticmethod
    def des_instance():

        if not NBNER.__SEG_INSTANCE:
            return
        NBNER.__SEG_INSTANCE=None

    @staticmethod
    def version():
        return "nb_ner_1.0"

    @staticmethod
    def __fill_prototype(f, restype, argtypes):
        f.restype = restype
        f.argtypes = argtypes

if __name__=="__main__":

    model_name = 'model.25'
    nb_ner = NBNER.get_instance(model_name)
    if not nb_ner:
        print 'error init_ner error'
        sys.exit(-1)
    
    file_name = 'test_file.utf8'
#    file_name = 'test_file.big'
    f = open(file_name)
    start_time = time.time()
    for line in f:
        line = line.strip()
        line = line.replace(' ','')
        try:
            line = line.decode('utf8')
        except Exception as e:
            continue 

        line = line.encode('gbk')
        res_str = nb_ner.seg_sentence(line)
        
        try:
            res_str = res_str.decode("gbk").encode('utf8')
            print res_str
        except Exception as e:
            print line.decode("gbk").encode("utf-8")
            res_str = res_str.decode("gbk","ignore").encode("utf-8")
            print res_str
            raise(e);
    end_time = time.time()
    print str(end_time-start_time) + 's'
    f.close();
